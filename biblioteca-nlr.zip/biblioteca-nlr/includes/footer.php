<footer class="site-footer"><strong>BookNet</strong><span>BookNet · <?= date('Y') ?></span></footer></body></html>
