<?php
require_once __DIR__.'/../config/auth.php';
require_admin();
$error='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    try{
        $title=trim($_POST['titulo'] ?? '');
        $subject=trim($_POST['disciplina'] ?? '');
        if(!$title||!$subject) throw new RuntimeException('Título e disciplina são obrigatórios.');

        $perguntas = $_POST['pergunta'] ?? [];
        $alternativas = ['a'=>$_POST['a'] ?? [], 'b'=>$_POST['b'] ?? [], 'c'=>$_POST['c'] ?? [], 'd'=>$_POST['d'] ?? []];
        $corretas = $_POST['correta'] ?? [];

        $validQuestions=[];
        foreach($perguntas as $i=>$text){
            $text=trim($text);
            if($text==='') continue;
            foreach(['a','b','c','d'] as $key){
                if(trim($alternativas[$key][$i] ?? '')===''){
                    throw new RuntimeException('Preencha todas as alternativas da pergunta '.($i+1).'.');
                }
            }
            $correct=$corretas[$i] ?? '';
            if(!in_array($correct,['a','b','c','d'],true)){
                throw new RuntimeException('Escolha a resposta correta da pergunta '.($i+1).'.');
            }
            $validQuestions[]=[
                $text,
                trim($alternativas['a'][$i]),
                trim($alternativas['b'][$i]),
                trim($alternativas['c'][$i]),
                trim($alternativas['d'][$i]),
                $correct
            ];
        }

        $count=count($validQuestions);
        if($count<5 || $count>10){
            throw new RuntimeException('O quiz precisa ter no mínimo 5 e no máximo 10 perguntas.');
        }

        db()->beginTransaction();
        $s=db()->prepare('INSERT INTO quizzes(titulo,disciplina,descricao,criado_por) VALUES(?,?,?,?)');
        $s->execute([$title,$subject,trim($_POST['descricao'] ?? ''),user()['id']]);
        $quiz=(int)db()->lastInsertId();
        $q=db()->prepare('INSERT INTO quiz_perguntas(quiz_id,pergunta,alternativa_a,alternativa_b,alternativa_c,alternativa_d,correta) VALUES(?,?,?,?,?,?,?)');
        foreach($validQuestions as $item){
            $q->execute([$quiz,$item[0],$item[1],$item[2],$item[3],$item[4],$item[5]]);
        }
        db()->commit();
        flash('success','Quiz publicado com '.$count.' perguntas.');
        redirect('admin/quizzes.php');
    }catch(Throwable $e){
        if(db()->inTransaction()) db()->rollBack();
        $error=$e->getMessage();
    }
}

$items=db()->query('SELECT q.*,COUNT(p.id) perguntas FROM quizzes q LEFT JOIN quiz_perguntas p ON p.quiz_id=q.id GROUP BY q.id ORDER BY q.created_at DESC')->fetchAll();
$pageTitle='Quizzes';
require __DIR__.'/../includes/header.php';
require __DIR__.'/../includes/dashboard-nav.php';
?>
<form class="panel" method="post" id="quiz-form">
<?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?>
<?=csrf_field()?>
<h2>Criar quiz</h2>
<p class="subtext">O quiz deve ter <b>no mínimo 5 e no máximo 10 perguntas</b>. As alternativas serão embaralhadas para cada aluno.</p>
<div class="form-grid">
<div class="form-group"><label>Título</label><input required name="titulo" placeholder="Revisão de frações"></div>
<div class="form-group"><label>Disciplina</label><input required name="disciplina" placeholder="Matemática"></div>
</div>
<div class="form-group"><label>Orientação</label><textarea name="descricao"></textarea></div>

<div id="questions-container">
<?php for($i=0;$i<5;$i++):?>
<fieldset class="quiz-question" style="border:1px solid #d9e2ec;border-radius:10px;margin:14px 0;padding:14px" data-question="<?=$i+1?>">
<legend>Pergunta <?=$i+1?></legend>
<div class="form-group"><label>Pergunta</label><input name="pergunta[]" <?= $i<5?'required':'' ?>></div>
<div class="form-grid">
<?php foreach(['a'=>'Alternativa A','b'=>'Alternativa B','c'=>'Alternativa C','d'=>'Alternativa D'] as $key=>$label):?>
<div class="form-group"><label><?=$label?></label><input name="<?=$key?>[]" <?= $i<5?'required':'' ?>></div>
<?php endforeach;?>
</div>
<div class="form-group"><label>Resposta correta</label><select name="correta[]"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select></div>
</fieldset>
<?php endfor;?>
</div>

<button class="btn" type="button" id="add-question">+ Adicionar pergunta</button>
<button class="btn" type="submit">Publicar quiz</button>
</form>

<section class="panel"><h2>Quizzes publicados</h2>
<?php foreach($items as $q):?>
<p><b><?=e($q['titulo'])?></b> · <?=e($q['disciplina'])?> <span class="badge"><?=$q['perguntas']?> pergunta(s)</span></p>
<?php endforeach;?>
</section>

<script>
(function(){
    const container=document.getElementById('questions-container');
    const add=document.getElementById('add-question');
    let count=container.querySelectorAll('.quiz-question').length;

    function update(){
        const total=container.querySelectorAll('.quiz-question').length;
        add.disabled=total>=10;
        add.textContent=total>=10?'Limite de 10 perguntas atingido':'+ Adicionar pergunta';
    }

    add.addEventListener('click',function(){
        const total=container.querySelectorAll('.quiz-question').length;
        if(total>=10) return;
        count++;
        const field=document.createElement('fieldset');
        field.className='quiz-question';
        field.style.cssText='border:1px solid #d9e2ec;border-radius:10px;margin:14px 0;padding:14px';
        field.dataset.question=count;
        field.innerHTML=`
            <legend>Pergunta ${count}</legend>
            <div class="form-group"><label>Pergunta</label><input name="pergunta[]" required></div>
            <div class="form-grid">
                <div class="form-group"><label>Alternativa A</label><input name="a[]" required></div>
                <div class="form-group"><label>Alternativa B</label><input name="b[]" required></div>
                <div class="form-group"><label>Alternativa C</label><input name="c[]" required></div>
                <div class="form-group"><label>Alternativa D</label><input name="d[]" required></div>
            </div>
            <div class="form-group"><label>Resposta correta</label><select name="correta[]"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select></div>`;
        container.appendChild(field);
        update();
    });

    document.getElementById('quiz-form').addEventListener('submit',function(e){
        const total=Array.from(container.querySelectorAll('.quiz-question')).filter(f=>f.querySelector('input[name="pergunta[]"]').value.trim()!=='').length;
        if(total<5 || total>10){
            e.preventDefault();
            alert('O quiz precisa ter no mínimo 5 e no máximo 10 perguntas.');
        }
    });
    update();
})();
</script>
<?php require __DIR__.'/../includes/dashboard-footer.php';?>
