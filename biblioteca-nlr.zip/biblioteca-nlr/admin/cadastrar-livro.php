<?php
require_once __DIR__.'/../config/auth.php'; require_admin(); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){ verify_csrf(); try {
    $d=array_map('trim',$_POST);
    if(!$d['titulo']||!$d['autor']||!(int)$d['quantidade']) throw new RuntimeException('Título, autor e quantidade são obrigatórios.');
    $cover=upload_cover($_FILES['capa']); $pdf=upload_pdf($_FILES['arquivo_pdf']);
    $s=db()->prepare('INSERT INTO livros(codigo_barras,isbn,titulo,autor,categoria,editora,ano_publicacao,quantidade,quantidade_disponivel,descricao,biografia_autor,capa,arquivo_pdf) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $s->execute([$d['codigo_barras'],$d['isbn'],$d['titulo'],$d['autor'],$d['categoria'],$d['editora'],(int)$d['ano_publicacao'],(int)$d['quantidade'],(int)$d['quantidade'],$d['descricao'],$d['biografia_autor'],$cover,$pdf]);
    flash('success','Livro cadastrado com sucesso.'); redirect('admin/livros.php');
} catch(Throwable $e){$error=$e->getMessage();} }
$pageTitle='Cadastrar livro'; require __DIR__.'/../includes/header.php'; require __DIR__.'/../includes/dashboard-nav.php';
?>
<form class="panel" method="post" enctype="multipart/form-data"><?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?><?=csrf_field()?>
<div class="form-grid"><div class="form-group"><label>Código de barras</label><input name="codigo_barras"></div><div class="form-group"><label>ISBN</label><input name="isbn"></div><div class="form-group"><label>Título *</label><input required name="titulo"></div><div class="form-group"><label>Autor *</label><input required name="autor"></div><div class="form-group"><label>Categoria</label><input name="categoria"></div><div class="form-group"><label>Editora</label><input name="editora"></div><div class="form-group"><label>Ano de publicação</label><input type="number" min="0" name="ano_publicacao"></div><div class="form-group"><label>Quantidade *</label><input required type="number" min="1" name="quantidade" value="1"></div></div>
<div class="form-group"><label>Descrição</label><textarea name="descricao"></textarea></div><div class="form-group"><label>Biografia do autor</label><textarea name="biografia_autor"></textarea></div><div class="form-group"><label>Capa (JPG, PNG ou WEBP, até 3 MB)</label><input data-cover-input type="file" accept="image/jpeg,image/png,image/webp" name="capa"></div><div class="form-group"><label>PDF do livro (opcional, até 20 MB)</label><input type="file" accept="application/pdf,.pdf" name="arquivo_pdf"></div><p class="subtext">Sem PDF = fica em “Livros da escola”. Com PDF = aparece em “Ler livros digitais”.</p><button class="btn">Cadastrar livro</button></form>
<?php require __DIR__.'/../includes/dashboard-footer.php'; ?>
