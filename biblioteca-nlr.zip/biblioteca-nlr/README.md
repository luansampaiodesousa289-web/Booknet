# BookNet

Sistema escolar em PHP 8+ e MySQL para a BookNet.

## Instalação

1. Copie esta pasta para `htdocs/booknet` (XAMPP) ou para a pasta pública do seu servidor PHP.
2. Crie/importa o banco pelo phpMyAdmin usando `database/biblioteca.sql`.
3. Confira credenciais do MySQL em `config/database.php` (padrão do XAMPP: usuário `root`, senha vazia).
4. Garanta permissão de gravação em `assets/uploads/capas/`.
5. Inicie Apache e MySQL e acesse `http://localhost/booknet/`.

## Acesso de teste

- Administrador: `admin@bibliotecanlr.com`
- Senha: `Admin@123`

As senhas dos dados de demonstração usam hash PHP. Alunos de exemplo têm a mesma senha.
