<?php
require_once __DIR__.'/../config/auth.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$s = db()->prepare('SELECT * FROM quizzes WHERE id=?');
$s->execute([$id]);
$quiz = $s->fetch();

if (!$quiz) {
    exit('Quiz não encontrado.');
}

$p = db()->prepare('SELECT * FROM quiz_perguntas WHERE quiz_id=? ORDER BY id');
$p->execute([$id]);
$questions = $p->fetchAll();

/*
 * Cada aluno recebe uma ordem própria para as alternativas.
 * A ordem fica salva no banco para não mudar ao recarregar a página.
 * Ex.: "c,a,d,b" significa:
 * A = alternativa original C
 * B = alternativa original A
 * C = alternativa original D
 * D = alternativa original B
 */
try {
    db()->exec("
        CREATE TABLE IF NOT EXISTS quiz_ordens_alternativas (
            usuario_id INT UNSIGNED NOT NULL,
            quiz_id INT UNSIGNED NOT NULL,
            pergunta_id INT UNSIGNED NOT NULL,
            ordem CHAR(4) NOT NULL,
            PRIMARY KEY (usuario_id, pergunta_id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
            FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
            FOREIGN KEY (pergunta_id) REFERENCES quiz_perguntas(id) ON DELETE CASCADE
        )
    ");
} catch (Throwable $e) {
    exit('Não foi possível preparar o embaralhamento das alternativas: '.e($e->getMessage()));
}

$usuarioId = (int)user()['id'];

/* Recupera as ordens já salvas para este aluno e este quiz. */
$orderStmt = db()->prepare(
    'SELECT pergunta_id, ordem FROM quiz_ordens_alternativas WHERE usuario_id=? AND quiz_id=?'
);
$orderStmt->execute([$usuarioId, $id]);
$savedOrders = [];
foreach ($orderStmt->fetchAll() as $row) {
    $savedOrders[(int)$row['pergunta_id']] = str_split($row['ordem']);
}

/* Cria uma ordem aleatória para cada pergunta que ainda não possui uma. */
$saveOrder = db()->prepare(
    'INSERT INTO quiz_ordens_alternativas(usuario_id,quiz_id,pergunta_id,ordem)
     VALUES(?,?,?,?)'
);

foreach ($questions as $q) {
    $qid = (int)$q['id'];

    if (
        !isset($savedOrders[$qid]) ||
        count($savedOrders[$qid]) !== 4 ||
        count(array_unique($savedOrders[$qid])) !== 4
    ) {
        $letters = ['a', 'b', 'c', 'd'];
        shuffle($letters);
        $savedOrders[$qid] = $letters;

        try {
            $saveOrder->execute([$usuarioId, $id, $qid, implode('', $letters)]);
        } catch (PDOException $e) {
            /* Se já existir por concorrência, usa a ordem que já estiver no banco. */
            $reload = db()->prepare(
                'SELECT ordem FROM quiz_ordens_alternativas
                 WHERE usuario_id=? AND quiz_id=? AND pergunta_id=?'
            );
            $reload->execute([$usuarioId, $id, $qid]);
            $existing = $reload->fetchColumn();

            if ($existing && strlen($existing) === 4) {
                $savedOrders[$qid] = str_split($existing);
            }
        }
    }
}

$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $hits = 0;
    $save = db()->prepare(
        'INSERT INTO quiz_respostas(usuario_id,pergunta_id,resposta)
         VALUES(?,?,?)
         ON DUPLICATE KEY UPDATE resposta=VALUES(resposta),created_at=CURRENT_TIMESTAMP'
    );

    foreach ($questions as $q) {
        $qid = (int)$q['id'];
        /*
         * O value enviado pelo formulário é a letra ORIGINAL da alternativa.
         * Portanto, mesmo com as opções embaralhadas, a correção continua correta.
         */
        $answer = $_POST['q'][$qid] ?? '';

        if (in_array($answer, ['a','b','c','d'], true)) {
            $save->execute([$usuarioId, $qid, $answer]);

            if ($answer === $q['correta']) {
                $hits++;
            }
        }
    }

    $total = count($questions);
    $nota = $total > 0 ? round(($hits / $total) * 10, 2) : 0;

    $result = [$hits, $total, $nota];
}

$pageTitle = $quiz['titulo'];
require __DIR__.'/../includes/header.php';
require __DIR__.'/../includes/dashboard-nav.php';
?>
<form class="panel" method="post">
    <?=csrf_field()?>
    <h2><?=e($quiz['titulo'])?></h2>
    <p class="subtext"><?=e($quiz['descricao'])?></p>

    <?php if ($result): ?>
        <div class="notice success">
            Você acertou <?=$result[0]?> de <?=$result[1]?> questões.
            <strong>Nota: <?=number_format($result[2], 2, ',', '.') ?>/10</strong>
        </div>
    <?php endif; ?>

    <?php foreach ($questions as $i => $q): ?>
        <?php
        $qid = (int)$q['id'];
        $order = $savedOrders[$qid];
        ?>
        <fieldset style="border:0;border-top:1px solid #d9e2ec;padding:18px 0">
            <legend><b><?=$i+1?>. <?=e($q['pergunta'])?></b></legend>

            <?php foreach ($order as $position => $originalLetter): ?>
                <label style="display:block;margin:10px 0">
                    <input
                        required
                        type="radio"
                        name="q[<?=$qid?>]"
                        value="<?=$originalLetter?>"
                    >
                    <strong><?=chr(65 + $position)?>)</strong>
                    <?=e($q['alternativa_'.$originalLetter])?>
                </label>
            <?php endforeach; ?>
        </fieldset>
    <?php endforeach; ?>

    <button class="btn" type="submit">Enviar respostas</button>
</form>
<?php require __DIR__.'/../includes/dashboard-footer.php'; ?>
