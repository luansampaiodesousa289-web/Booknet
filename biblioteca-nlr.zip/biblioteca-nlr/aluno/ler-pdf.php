<?php
require_once __DIR__ . '/../config/auth.php';
require_login();
$s = db()->prepare('SELECT titulo, arquivo_pdf FROM livros WHERE id=?');
$s->execute([(int)($_GET['id'] ?? 0)]);
$book = $s->fetch();
if (!$book || !$book['arquivo_pdf']) { http_response_code(404); exit('Livro digital não encontrado.'); }
$path = dirname(__DIR__) . '/assets/uploads/pdfs/' . basename($book['arquivo_pdf']);
if (!is_file($path)) { http_response_code(404); exit('O arquivo PDF não está disponível.'); }
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="livro-digital.pdf"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
