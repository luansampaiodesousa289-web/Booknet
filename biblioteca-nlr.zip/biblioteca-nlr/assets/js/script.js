document.addEventListener('DOMContentLoaded',()=>{document.querySelector('.toast')&&setTimeout(()=>document.querySelector('.toast').remove(),4200);document.querySelectorAll('.menu-toggle').forEach(b=>b.addEventListener('click',()=>{document.querySelector('.sidebar')?.classList.toggle('open');document.querySelector('.nav nav')?.classList.toggle('open')}));document.querySelectorAll('[data-confirm]').forEach(b=>b.addEventListener('click',e=>{if(!confirm(b.dataset.confirm))e.preventDefault()}));const input=document.querySelector('[data-catalog-search]');if(input){input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();input.form?.requestSubmit()}})}const file=document.querySelector('[data-cover-input]');if(file)file.addEventListener('change',()=>{const img=document.querySelector('[data-cover-preview]');if(file.files[0]&&img)img.src=URL.createObjectURL(file.files[0])})});


function setBooknetTheme(theme){
  if(theme!=='dark' && theme!=='light') return;
  document.documentElement.dataset.theme=theme==='dark'?'dark':'';
  try{localStorage.setItem('booknet-theme',theme);}catch(e){}
  document.querySelectorAll('[data-theme-choice]').forEach(el=>{
    const active=el.dataset.themeChoice===theme;
    el.classList.toggle('theme-active',active);
    el.setAttribute('aria-pressed',active?'true':'false');
  });
}

document.addEventListener('DOMContentLoaded',()=>{
  let theme='light';
  try{theme=localStorage.getItem('booknet-theme')||'light';}catch(e){}
  setBooknetTheme(theme);
});
